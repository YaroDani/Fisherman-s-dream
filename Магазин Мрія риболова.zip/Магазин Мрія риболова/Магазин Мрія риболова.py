from tkinter import*
from tkinter import ttk
from tkinter import messagebox
k = 0
foto = ["01.png","02.png","03.png","04.png","05.png","06.png","07.png"]

def step(link):
    global k
    if(link==">"):
        k = k+1
        if k>6:k=0
        img = PhotoImage(file=foto[k])
        tovar.create_image(202,202, image = img)
        tovar.image = img
    if(link=="<"):
        k = k-1
        if k<0:k=6
        img = PhotoImage(file=foto[k])
        tovar.create_image(202,202, image = img)
        tovar.image = img

def plata():
    summa = 0
    if pack.get==0 or (product1.get()==0 and product2.get()==0 and product3.get()==0 and
    product4.get()==0 and product5.get()==0 and product6.get()==0 and
    product7.get()==0):
        messagebox.showinfo("Увага","Ви обрали не всі позиції,поверніться до вибору товарів")
    else:
        if (product1.get()!=0 and pr1.get()=="") or (product2.get()!=0 and
            pr2.get()=="") or (product3.get()!=0 and
            pr3.get()=="") or (product4.get()!=0 and pr4.get()=="") or (product5.get()!=0 and
            pr5.get()=="") or   (product6.get()!=0 and
            pr6.get()=="")or   (product7.get()!=0  and pr7.get()==""):
                messagebox.showinfo ("Увага", "Ви не обрали кількість обраних товарів")
        else:
            if pack.get()==1: summa=summa+1000
            if pack.get()==2: summa=summa+600
            if pack.get()==3: summa=summa+400
            if (product1.get()!=0 and pr1.get()!=""): summa=summa+int(product1.get())*int(pr1.get())
            if (product2.get()!=0 and pr2.get()!=""): summa=summa+int(product2.get())*int(pr2.get())
            if (product3.get()!=0 and pr3.get()!=""): summa=summa+int(product3.get())*int(pr3.get())
            if (product4.get()!=0 and pr4.get()!=""): summa=summa+int(product4.get())*int(pr4.get())
            if (product5.get()!=0 and pr5.get()!=""): summa=summa+int(product5.get())*int(pr5.get())
            if (product6.get()!=0 and pr6.get()!=""): summa=summa+int(product6.get())*int(pr6.get())
            if (product7.get()!=0 and pr7.get()!=""): summa=summa+int(product7.get())*int(pr7.get())
            summa=summa-summa*int(zn.get())/100
            zagolovok5.config(text="До сплати "+" "+str(summa)+" грн")
mag = Tk()
mag.geometry("1200x800")
mag.title("Магазин \"МРІЯ РИБОЛОВА\"")
mag["bg"] = "blue"

zagolovok = Label(mag,
                  text = "Магазин \"МРІЯ РИБОЛОВА\"",
                  font = ("Arial",60, "bold"),
                  fg = "yellow",
                  bg="brown")
zagolovok.place(x = 50, y = 20)

img=PhotoImage(file = "01.png")
tovar = Canvas(mag,width = "400",height="400",bg="white")
tovar.create_image(202,202, image = img)
tovar.place(x = 20, y = 120)

zagolovok2 = Label(mag,
                  text = "Обери комплектацію обраних товарів",
                  font = ("Arial",16, "bold"),
                  fg = "yellow",
                  bg="brown")
zagolovok2.place(x = 600, y = 120)

img1=PhotoImage(file = "pack1.png")
packing1 = Canvas(mag,width = "150",height="150",bg="white")
packing1.create_image(76,76, image = img1)
packing1.place(x = 450, y = 160)

img2=PhotoImage(file = "pack2.png")
packing2 = Canvas(mag,width = "150",height="150",bg="white")
packing2.create_image(76,76, image = img2)
packing2.place(x = 640, y = 160)

img3=PhotoImage(file = "pack3.png")
packing3 = Canvas(mag,width = "150",height="150",bg="white")
packing3.create_image(76,76, image = img3)
packing3.place(x = 830, y = 160)

pack=IntVar()
p1=Radiobutton(mag,
                text = "Варіант №1: \n 1000грн.",
                font = ("Arial",16, "bold"),
                fg = "yellow",
               value=1, variable=pack,
                bg="brown")
p1.place(x=440, y=320)

p2=Radiobutton(mag,
                text = "Варіант №2: \n 600грн.",
                font = ("Arial",16, "bold"),
                fg = "yellow",
               value=2, variable=pack,
                bg="brown")
p2.place(x=630, y=320)

p3=Radiobutton(mag,
                text = "Варіант №3: \n 400грн.",
                font = ("Arial",16, "bold"),
                fg = "yellow",
               value=3, variable=pack,
                bg="brown")
p3.place(x=820, y=320)

zagolovok3 = Label(mag,
                  text = "Обери товари та вкажи потрібну кількість",
                  font = ("Arial",16, "bold"),
                  fg = "yellow",
                  bg="brown")
zagolovok3.place(x = 480, y = 380)
#--------------------------------------------
product1=IntVar()
cb_p1=Checkbutton(mag,
                text = "Фідерне вудилище-1500 грн. (1шт):",
                font = ("Arial",16, "bold"),
                  onvalue=1500,
                fg = "yellow", variable=product1,
                bg="green")
cb_p1.place(x=450, y=410)

pr1=Entry(mag,font = ("Arial",16, "bold"))
pr1.place(x=900, y=410, width=150 )
#-----------------------------------------------
product2=IntVar()
cb_p2=Checkbutton(mag,
                text = "Коропове вудилище-2000 грн. (1шт):",
                font = ("Arial",16, "bold"),
                  onvalue=2000,
                fg = "yellow", variable=product2,
                bg="green")
cb_p2.place(x=450, y=445)

pr2=Entry(mag,font = ("Arial",16, "bold"))
pr2.place(x=900, y=445, width=150 )
#-----------------------------------------------
product3=IntVar()
cb_p3=Checkbutton(mag,
                text = "Болонське вудилише-1100 грн. (1шт):",
                font = ("Arial",16, "bold"),
                  onvalue=1100,
                fg = "yellow", variable=product3,
                bg="green")
cb_p3.place(x=450, y=480)

pr3=Entry(mag,font = ("Arial",16, "bold"))
pr3.place(x=900, y=480, width=150 )
#-----------------------------------------------
product4=IntVar()
cb_p4=Checkbutton(mag,
                text = "Махове вудилище-800 грн. (1шт):",
                font = ("Arial",16, "bold"),
                  onvalue=800,
                fg = "yellow", variable=product4,
                bg="green")
cb_p4.place(x=450, y=515)

pr4=Entry(mag,font = ("Arial",16, "bold"))
pr4.place(x=900, y=515, width=150 )
#-----------------------------------------------
product5=IntVar()
cb_p5=Checkbutton(mag,
                text = "Основна волосінь-150 грн. (1шт):",
                font = ("Arial",16, "bold"),
                  onvalue=150,
                fg = "yellow", variable=product5,
                bg="green")
cb_p5.place(x=450, y=550)

pr5=Entry(mag,font = ("Arial",16, "bold"))
pr5.place(x=900, y=550, width=150 )
#-----------------------------------------------
product6=IntVar()
cb_p6=Checkbutton(mag,
                text = "Повідцева волосінь 80 грн. (1шт):",
                font = ("Arial",16, "bold"),
                  onvalue=80,
                fg = "yellow", variable=product6,
                bg="green")
cb_p6.place(x=450, y=585)

pr6=Entry(mag,font = ("Arial",16, "bold"))
pr6.place(x=900, y=585, width=150 )
#-----------------------------------------------
product7=IntVar()
cb_p7=Checkbutton(mag,
                text = "Гачки-30 грн. (1 упаковка):",
                font = ("Arial",16, "bold"),
                  onvalue=30,
                fg = "yellow", variable=product7,
                bg="green")
cb_p7.place(x=450, y=620)

pr7=Entry(mag,font = ("Arial",16, "bold"))
pr7.place(x=900, y=620, width=150 )
#-----------------------------------------------
butt1=Button(mag,font = ("Arial",16, "bold"), text="<<<<<",
           command = lambda:step("<"))
butt1.place(x=20, y=530, width=200 )
butt2=Button(mag,font = ("Arial",16, "bold"), text=">>>>>",
           command = lambda:step(">"))
butt2.place(x=222, y=530, width=200 )
#-----------------------------------------------
zagolovok4 = Label(mag,
                  text = "Маєш купон знижки? \n Обери відсоток:",
                  font = ("Arial",16, "bold"),
                  fg = "yellow",
                  bg="green")
zagolovok4.place(x = 30, y = 580)
#-----------------------------------------------
zn=ttk.Combobox(mag,font = ("Arial",16, "bold"),
               value=[0,10,20,30] )
zn.current(0)
zn.place(x = 280, y = 590, width=100)
#-----------------------------------------------
result=Button(mag,font = ("Arial",20, "bold"),
              text="Порахувати вартість обраного букету",
              command = lambda:plata())
result.place(x=50, y=680, width=600, height=40 )
#-----------------------------------------------
zagolovok5 = Label(mag,
                  text = "До сплати 0 грн.",
                  font = ("Arial",20, "bold"),
                  fg = "yellow",
                  bg="green")
zagolovok5.place(x = 700, y = 680)
#-----------------------------------------------
#-----------------------------------------------
